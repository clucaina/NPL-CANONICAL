# NPL-CANONICAL — Developer handoff

## What this is
NPL is a local-first interactive product built around one canonical anatomical 3D brain. The immediate goal is not to rebuild the product, but to continue from this repository without regressions.

## Non-negotiable continuity rules
1. Do not replace `public/assets/brain/brain.glb` without an explicit migration decision.
2. Do not substitute SVG/canvas/iframe brains for the canonical atlas.
3. Preserve `manifest.json`, structure IDs, hierarchy, selection, hover, focus, hemispheres, deep structures, tracts and touch behavior.
4. Keep personal/network overlays epistemically separate from anatomy. Behavioral evidence must never be described as measured neural activation.
5. Historical kernel code under `legacy/` is reference/source code until explicitly connected and tested.

## First blocker
The canonical GLB contains Draco-compressed primitives. `BrainViewer.tsx` expects a decoder under:

`public/vendor/draco/gltf/`

Preferred files:
- `draco_wasm_wrapper.js`
- `draco_decoder.wasm`

Alternative:
- `draco_decoder.js` with matching loader configuration.

Do not promote `dist/assets/brain/brain.runtime.glb` to verified production runtime without comparing geometry against the canonical source.

## Canonical evidence
- `docs/BRAIN_ASSET_HASHES.txt`
- `public/assets/brain/provenance.json`
- `docs/CAPABILITY_REGISTRY.json`
- `docs/NPL-RELEASE-GATE.json`
- `docs/BRAIN-GATE.json`

## Suggested first successful vertical slice after Brain PASS
Experience → telemetry → event/session → feature → evidence → minimal Evidence Graph → profile state → distributed network → brain overlay → next-best experience.

Do not connect game → lobe directly.

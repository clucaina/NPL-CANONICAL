# Third-party asset notes

Canonical brain asset provenance is recorded in `public/assets/brain/provenance.json`.

Recorded upstream:
- Project: `itayinbarr/brainproject`
- Asset path: `brain-atlas/models/brain.glb`
- Anatomy asset license recorded by the project: CC BY-SA 4.0
- Viewer/source license recorded by the project: Apache-2.0

Before public redistribution, deployment, or relicensing, review the upstream repository's current license/attribution requirements. Preserve attribution in downstream builds.

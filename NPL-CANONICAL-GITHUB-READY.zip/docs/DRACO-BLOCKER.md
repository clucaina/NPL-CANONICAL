# Draco local blocker

- Canonical `brain.glb` is present and requires `KHR_draco_mesh_compression`.
- 563 compressed primitives were detected.
- `BrainViewer.tsx` already points to `/vendor/draco/gltf/`.
- No physical Draco decoder was found in the project, installed Three package cache, Chromium cache, historical NPL artifacts, or the recovered corporate deploy ZIP.
- Direct package/CDN access from this container is blocked at network level.
- Historical self-contained brain HTML contains a decompressed GLB copy, not a vendored Draco decoder.
- Therefore the decompressed GLB may be used only as a QA fixture; it cannot satisfy the canonical production gate.

## Files that unblock the gate
Preferred WASM runtime:
- `public/vendor/draco/gltf/draco_wasm_wrapper.js`
- `public/vendor/draco/gltf/draco_decoder.wasm`

Alternative JS runtime (requires forcing decoder type `js` in `BrainViewer`):
- `public/vendor/draco/gltf/draco_decoder.js`

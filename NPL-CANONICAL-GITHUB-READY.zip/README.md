# NPL-CANONICAL

Canonical handoff repository for NPL. This repository is intentionally local-first and preserves the anatomical brain component as a protected asset.

## Canonical protected assets

- `public/assets/brain/brain.glb` — canonical anatomical source asset. Do not replace or regenerate casually.
- `public/assets/brain/manifest.json` — canonical structure metadata.
- `src/components/BrainViewer.tsx` — canonical viewer component.
- `legacy/kernel/NPL-V41-LIVE-PREVIEW.html` — archived historical kernel reference; archived is not the same as connected.

## Current execution state

The canonical source GLB uses `KHR_draco_mesh_compression`. A compatible local Draco decoder is not currently vendored under `public/vendor/draco/gltf/`, so the canonical compressed runtime is **not yet a production PASS**.

`dist/assets/brain/brain.runtime.glb` and QA fixtures must **not** be treated as verified production replacements unless their geometry is independently validated. See `docs/DRACO-BLOCKER.md` and `docs/NPL-RELEASE-GATE.json`.

## Local development

Requirements: Node.js + npm and Python 3 for QA scripts.

```bash
npm install
npm run dev
```

Brain gate:

```bash
npm run brain:gate
```

## Handoff

Start with `DEVELOPER_HANDOFF.md`. The first technical task is to restore a compatible local Draco decoder or produce a rigorously verified decompressed deploy runtime from the canonical GLB without changing atlas content.

## Scientific boundary

Network/progress overlays are NPL evidence visualizations, not measured neural activation, fMRI/EEG, neural power, brain capacity, or anatomical change.

## Third-party anatomy provenance

The brain asset provenance is recorded in `public/assets/brain/provenance.json`. Upstream anatomy assets are identified there as CC BY-SA 4.0; viewer/source licensing references are also preserved. Keep attribution and verify obligations before redistribution/deployment.

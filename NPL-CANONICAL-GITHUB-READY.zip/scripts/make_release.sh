#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
OUT=/mnt/data/NPL-CANONICAL.zip
COMMIT="$(git rev-parse HEAD 2>/dev/null || echo NO_GIT_COMMIT)"
STATUS="$(python3 - <<'PY'
import json
from pathlib import Path
p=Path('docs/BRAIN-GATE.json')
print(json.loads(p.read_text()).get('status','UNKNOWN') if p.exists() else 'UNKNOWN')
PY
)"
cat > RELEASE_METADATA.json <<EOF
{
  "product": "NPL-CANONICAL",
  "gitCommit": "$COMMIT",
  "brainGate": "$STATUS",
  "note": "Recoverable canonical snapshot; gate status is evidence-based and may be FAIL."
}
EOF
rm -f "$OUT"
zip -qr "$OUT" . -x '.git/*' 'node_modules/*' '*.pyc' '__pycache__/*'
rm -f RELEASE_METADATA.json
echo "$OUT"

import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { DRACOLoader } from "three/examples/jsm/loaders/DRACOLoader.js";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { NETWORKS, type NetworkId } from "../data/networkRegistry";
import { MOCK_PROGRESS, progressState } from "../data/mockProgress";

const MODEL_URL = "/assets/brain/brain.glb";
const MANIFEST_URL = "/assets/brain/manifest.json";
const DRACO_PATH = "/vendor/draco/gltf/";

type Mode = "anatomy" | "networks" | "progress" | "learn";
type Side = "left" | "right" | "median";
type Meta = {id:number|null;label:string;category:string;side:Side;region:string;source?:string};
type Manifest = {nodes: Array<Meta & {name:string}>};

type BrainApi = {
  reset(): void;
  focus(): void;
  setMode(mode: Mode): void;
  setNetwork(id: NetworkId): void;
};

const norm=(s:string)=>s.toLowerCase().trim().replace(/\.\d{3}$/,'').replace(/\.(l|r)$/,'').replace(/\s+/g,' ');
const networkMatches=(meta:Meta,id:NetworkId)=>{
  const n=NETWORKS.find(x=>x.id===id); if(!n)return false;
  const text=`${meta.label} ${meta.region} ${meta.category}`.toLowerCase();
  return n.structurePatterns.some(p=>text.includes(p.toLowerCase()));
};

/**
 * Canonical Brain PASS renderer.
 * The GLB is never modified here; all NPL semantics are overlays on the same atlas.
 */
export function BrainViewer(){
  const mountRef=useRef<HTMLDivElement>(null);
  const apiRef=useRef<BrainApi|null>(null);
  const [mode,setModeState]=useState<Mode>("anatomy");
  const [activeNetwork,setActiveNetwork]=useState<NetworkId>("control");
  const [selectedLabel,setSelectedLabel]=useState<string|null>(null);
  const [status,setStatus]=useState("Cargando atlas…");

  useEffect(()=>{
    const mount=mountRef.current;if(!mount)return;
    const scene=new THREE.Scene();
    const camera=new THREE.PerspectiveCamera(42,mount.clientWidth/mount.clientHeight,.001,100);
    const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:"high-performance"});
    renderer.setPixelRatio(Math.min(devicePixelRatio,1.75));renderer.setSize(mount.clientWidth,mount.clientHeight);
    renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;
    mount.appendChild(renderer.domElement);
    scene.add(new THREE.HemisphereLight(0xf8f3ee,0x202632,1.4));
    const key=new THREE.DirectionalLight(0xfff4eb,2.5);key.position.set(2.5,3.5,4);scene.add(key);
    const rim=new THREE.DirectionalLight(0xb9d2ea,1.0);rim.position.set(-3,1,-2);scene.add(rim);

    const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.enablePan=true;controls.screenSpacePanning=true;
    controls.touches={ONE:THREE.TOUCH.ROTATE,TWO:THREE.TOUCH.DOLLY_PAN};
    const raycaster=new THREE.Raycaster();const pointer=new THREE.Vector2();
    let meshes:THREE.Mesh[]=[];let selected:THREE.Mesh|null=null;let hovered:THREE.Mesh|null=null;let brain:THREE.Object3D|null=null;
    let home={pos:new THREE.Vector3(0,0,3),target:new THREE.Vector3()};let drag=false;let down={x:0,y:0,t:0};let hoverTimer:number|undefined;
    let currentMode:Mode="anatomy";let currentNetwork:NetworkId="control";let cortexOpacity=.86;let hemi:"left"|"right"|"both"="both";
    const metaMap=new Map<string,Meta>();

    const apply=()=>{
      const net=NETWORKS.find(n=>n.id===currentNetwork);const p=MOCK_PROGRESS[currentNetwork];const ps=progressState(p);
      for(const m of meshes){const md=m.userData.meta as Meta;const mat=m.material as THREE.MeshStandardMaterial;
        m.visible=hemi==="both"||md.side===hemi||md.side==="median";
        mat.emissive.set(0);mat.emissiveIntensity=0;mat.transparent=true;mat.opacity=md.category==="cortex"?cortexOpacity:.96;
        if((currentMode==="networks"||currentMode==="progress")&&net){const yes=networkMatches(md,currentNetwork);mat.opacity=yes?.95:.08;if(yes){mat.color.set(net.color);mat.emissive.set(net.color);mat.emissiveIntensity=currentMode==="progress"?(ps==="stable"?.28:ps==="unknown"?0:.13):.10;}}
        if(m===hovered&&m!==selected){mat.emissive.set(0xffffff);mat.emissiveIntensity=.10;}
        if(m===selected){mat.color.set(0xf4eee9);mat.emissive.set(0xd59a7a);mat.emissiveIntensity=.35;mat.opacity=1;}
      }
      renderer.render(scene,camera);
    };
    const pick=(x:number,y:number)=>{const r=renderer.domElement.getBoundingClientRect();pointer.set(((x-r.left)/r.width)*2-1,-((y-r.top)/r.height)*2+1);raycaster.setFromCamera(pointer,camera);return (raycaster.intersectObjects(meshes.filter(m=>m.visible),false)[0]?.object as THREE.Mesh)||null};
    const fly=(m:THREE.Mesh|null)=>{if(!m)return;const sphere=new THREE.Box3().setFromObject(m).getBoundingSphere(new THREE.Sphere());const fromP=camera.position.clone(),fromT=controls.target.clone();const dir=fromP.clone().sub(fromT).normalize();const dist=Math.max(sphere.radius/Math.tan(camera.fov*Math.PI/360)*1.6,.035);const toP=sphere.center.clone().add(dir.multiplyScalar(dist));const t0=performance.now();const tick=(now:number)=>{const t=Math.min(1,(now-t0)/550),e=1-Math.pow(1-t,3);camera.position.lerpVectors(fromP,toP,e);controls.target.lerpVectors(fromT,sphere.center,e);controls.update();if(t<1)requestAnimationFrame(tick)};requestAnimationFrame(tick)};
    const reset=()=>{selected=null;hovered=null;hemi="both";cortexOpacity=.86;camera.position.copy(home.pos);controls.target.copy(home.target);controls.update();setSelectedLabel(null);apply()};
    apiRef.current={reset,focus:()=>fly(selected),setMode:m=>{currentMode=m;setModeState(m);apply()},setNetwork:id=>{currentNetwork=id;setActiveNetwork(id);apply()}};

    const onDown=(e:PointerEvent)=>{down={x:e.clientX,y:e.clientY,t:performance.now()};drag=false};
    const onMove=(e:PointerEvent)=>{if(Math.hypot(e.clientX-down.x,e.clientY-down.y)>6)drag=true;if(hoverTimer)clearTimeout(hoverTimer);hoverTimer=window.setTimeout(()=>{if(drag)return;const m=pick(e.clientX,e.clientY);if(m!==hovered){hovered=m;apply()}},46)};
    const onUp=(e:PointerEvent)=>{const click=!drag&&performance.now()-down.t<650;if(click){const m=pick(e.clientX,e.clientY);if(m){selected=m;setSelectedLabel((m.userData.meta as Meta).label);apply()}}drag=false};
    renderer.domElement.addEventListener("pointerdown",onDown);renderer.domElement.addEventListener("pointermove",onMove);renderer.domElement.addEventListener("pointerup",onUp);

    const draco=new DRACOLoader();draco.setDecoderPath(DRACO_PATH);const loader=new GLTFLoader();loader.setDRACOLoader(draco);
    Promise.all([fetch(MANIFEST_URL).then(r=>r.json() as Promise<Manifest>),loader.loadAsync(MODEL_URL)]).then(([manifest,gltf])=>{
      for(const x of manifest.nodes){metaMap.set(norm(x.label),x);metaMap.set(norm(x.name),x)}brain=gltf.scene;scene.add(brain);brain.traverse(o=>{const m=o as THREE.Mesh;if(!m.isMesh)return;const md=metaMap.get(norm(m.name))||metaMap.get(norm(m.parent?.name||""))||{id:null,label:m.name,category:"other",side:"median",region:""};m.userData.meta=md;m.material=new THREE.MeshStandardMaterial({color:0xd4b8ae,roughness:.72,metalness:.015,transparent:true,opacity:.96});meshes.push(m)});
      const core=meshes.filter(m=>!["arteries","veins_sinuses","cranial_nerves","meninges_dura"].includes((m.userData.meta as Meta).category));const box=new THREE.Box3();(core.length?core:meshes).forEach(m=>box.expandByObject(m));const sphere=box.getBoundingSphere(new THREE.Sphere());const dist=sphere.radius/Math.tan(camera.fov*Math.PI/360)*1.35;camera.position.copy(sphere.center.clone().add(new THREE.Vector3(dist*.1,dist*.08,dist)));controls.target.copy(sphere.center);controls.update();home={pos:camera.position.clone(),target:controls.target.clone()};setStatus(`${meshes.length} mallas · atlas local`);apply();
    }).catch(e=>setStatus(`ERROR: brain.glb no cargado · ${e instanceof Error?e.message:String(e)}`));
    let raf=0;const loop=()=>{raf=requestAnimationFrame(loop);controls.update();renderer.render(scene,camera)};loop();
    return()=>{cancelAnimationFrame(raf);if(hoverTimer)clearTimeout(hoverTimer);renderer.domElement.removeEventListener("pointerdown",onDown);renderer.domElement.removeEventListener("pointermove",onMove);renderer.domElement.removeEventListener("pointerup",onUp);controls.dispose();draco.dispose();renderer.dispose();mount.replaceChildren();apiRef.current=null};
  },[]);

  return <section className="npl-living-brain"><div ref={mountRef} className="brain-canvas"/><header><b>NPL · Living Brain</b><span>{status}</span></header><nav>{(["anatomy","networks","progress","learn"] as Mode[]).map(m=><button key={m} aria-pressed={mode===m} onClick={()=>apiRef.current?.setMode(m)}>{m}</button>)}</nav>{(mode==="networks"||mode==="progress")&&<div className="network-strip">{NETWORKS.map(n=><button key={n.id} aria-pressed={activeNetwork===n.id} onClick={()=>apiRef.current?.setNetwork(n.id)}>{n.name}</button>)}</div>}<aside hidden={!selectedLabel}><strong>{selectedLabel}</strong><button onClick={()=>apiRef.current?.focus()}>Enfocar</button></aside></section>;
}

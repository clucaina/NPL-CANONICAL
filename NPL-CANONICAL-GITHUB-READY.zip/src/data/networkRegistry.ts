export type NetworkId =
  | "visual" | "somatomotor" | "dorsal_attention" | "salience"
  | "control" | "default" | "language" | "memory" | "reward" | "social";

export type NetworkDefinition = {
  id: NetworkId;
  name: string;
  description: string;
  color: string;
  structurePatterns: string[];
  evidenceNote: string;
};

// Educational group-level mappings only. They are not personal neuroimaging.
export const NETWORKS: NetworkDefinition[] = [
  { id:"visual", name:"Visual", color:"#73b8ff", description:"Procesamiento e integración visual distribuida.", structurePatterns:["occipital","cuneus","calcarine","lingual","fusiform","occipitotemporal","optic radiation","lateral geniculate"], evidenceNote:"Initial literature-informed mapping; version and provenance required before scientific release." },
  { id:"somatomotor", name:"Somatomotora", color:"#74d5a7", description:"Percepción corporal, preparación y control del movimiento.", structurePatterns:["precentral","postcentral","paracentral","corticospinal","cerebell"], evidenceNote:"Distributed sensorimotor mapping." },
  { id:"dorsal_attention", name:"Atención dorsal", color:"#68d7e7", description:"Orientación voluntaria y selección de información relevante.", structurePatterns:["superior parietal","intraparietal","superior frontal","middle frontal"], evidenceNote:"Approximate distributed mapping; not a parcel-level functional atlas." },
  { id:"salience", name:"Atención ventral / salience", color:"#f4b86b", description:"Detección de relevancia y reorientación atencional.", structurePatterns:["insula","cingulate","opercular","supramarginal"], evidenceNote:"Distributed mapping; salience and ventral attention are kept conceptually distinguishable in later registry versions." },
  { id:"control", name:"Frontoparietal / control", color:"#bb9cff", description:"Control flexible, mantenimiento de metas y ajuste de estrategia.", structurePatterns:["middle frontal","inferior frontal","superior parietal","inferior parietal","angular gyrus","cingulate"], evidenceNote:"Distributed control systems." },
  { id:"default", name:"Default mode", color:"#e7a8cb", description:"Procesamiento interno, autobiográfico y modelos de situación.", structurePatterns:["precuneus","posterior cingulate","medial frontal","angular gyrus","parahippocamp","hippocamp"], evidenceNote:"Distributed DMN-like mapping." },
  { id:"language", name:"Lenguaje", color:"#f3d36f", description:"Comprensión, producción y control lingüístico distribuido.", structurePatterns:["inferior frontal","opercular part","triangular part","superior temporal","middle temporal","angular gyrus","supramarginal","acoustic radiation"], evidenceNote:"Core language and control-related territories; not a single language center." },
  { id:"memory", name:"Memoria", color:"#82c7c2", description:"Codificación, consolidación, recuperación y contexto.", structurePatterns:["hippocamp","parahippocamp","entorhinal","fornix","mammillary","posterior cingulate","thalam"], evidenceNote:"Multiple memory systems; this is a first visualization family." },
  { id:"reward", name:"Reward / value", color:"#f28e83", description:"Valoración, aprendizaje por recompensa y selección orientada a metas.", structurePatterns:["accumbens","orbitofrontal","orbital gyrus","medial frontal","caudate","putamen","amygdal"], evidenceNote:"Distributed value/reward mapping." },
  { id:"social", name:"Mentalizing / social cognition", color:"#89a9ef", description:"Perspectiva social y modelos de estados mentales.", structurePatterns:["temporoparietal","angular gyrus","supramarginal","precuneus","posterior cingulate","medial frontal","temporal pole"], evidenceNote:"Distributed social-cognition mapping." },
];

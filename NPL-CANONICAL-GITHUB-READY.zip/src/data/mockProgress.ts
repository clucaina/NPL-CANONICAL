import type { NetworkId } from "./networkRegistry";

export type NetworkProgress = {
  coverage: number;
  evidenceCount: number;
  evidenceDiversity: number;
  contexts: number;
  repetitions: number;
  timeSpan: number;
  transferEvidence: number;
  uncertainty: number;
  contradictions: number;
  lastEvidence: string;
  trend: string;
  confidence: number;
};

// MOCK only: validates visual semantics. It must never be persisted as user evidence.
export const MOCK_PROGRESS: Record<NetworkId, NetworkProgress> = {
  visual:{coverage:.58,evidenceCount:18,evidenceDiversity:4,contexts:3,repetitions:7,timeSpan:46,transferEvidence:2,uncertainty:.22,contradictions:0,lastEvidence:"hace 2 días",trend:"estable",confidence:.72},
  somatomotor:{coverage:.22,evidenceCount:6,evidenceDiversity:2,contexts:2,repetitions:3,timeSpan:16,transferEvidence:0,uncertainty:.48,contradictions:0,lastEvidence:"hace 6 días",trend:"explorando",confidence:.42},
  dorsal_attention:{coverage:.48,evidenceCount:14,evidenceDiversity:3,contexts:3,repetitions:6,timeSpan:34,transferEvidence:1,uncertainty:.31,contradictions:0,lastEvidence:"hoy",trend:"cambio reciente",confidence:.63},
  salience:{coverage:.31,evidenceCount:8,evidenceDiversity:3,contexts:2,repetitions:4,timeSpan:21,transferEvidence:0,uncertainty:.62,contradictions:2,lastEvidence:"hace 4 días",trend:"contradictorio",confidence:.34},
  control:{coverage:.62,evidenceCount:21,evidenceDiversity:5,contexts:4,repetitions:8,timeSpan:55,transferEvidence:2,uncertainty:.26,contradictions:1,lastEvidence:"ayer",trend:"estable",confidence:.74},
  default:{coverage:.12,evidenceCount:3,evidenceDiversity:1,contexts:1,repetitions:2,timeSpan:5,transferEvidence:0,uncertainty:.73,contradictions:0,lastEvidence:"hace 5 días",trend:"inicial",confidence:.22},
  language:{coverage:.39,evidenceCount:10,evidenceDiversity:4,contexts:3,repetitions:5,timeSpan:29,transferEvidence:1,uncertainty:.36,contradictions:0,lastEvidence:"hace 3 días",trend:"creciendo",confidence:.59},
  memory:{coverage:.45,evidenceCount:12,evidenceDiversity:3,contexts:3,repetitions:5,timeSpan:40,transferEvidence:1,uncertainty:.38,contradictions:1,lastEvidence:"hoy",trend:"variable",confidence:.55},
  reward:{coverage:0,evidenceCount:0,evidenceDiversity:0,contexts:0,repetitions:0,timeSpan:0,transferEvidence:0,uncertainty:1,contradictions:0,lastEvidence:"sin evidencia",trend:"desconocido",confidence:0},
  social:{coverage:.28,evidenceCount:7,evidenceDiversity:3,contexts:3,repetitions:3,timeSpan:26,transferEvidence:1,uncertainty:.44,contradictions:0,lastEvidence:"hace 1 semana",trend:"explorando",confidence:.49},
};

export function progressState(p: NetworkProgress) {
  if (!p.evidenceCount) return "unknown";
  if (p.contradictions >= 2) return "contradictory";
  if (p.uncertainty >= .60) return "uncertain";
  if (p.timeSpan >= 30 && p.repetitions >= 6 && p.evidenceDiversity >= 4 && p.contexts >= 3 && p.transferEvidence >= 2 && p.uncertainty < .35) return "stable";
  if (p.transferEvidence >= 1 && p.contexts >= 3) return "transferred";
  if (p.evidenceDiversity >= 3 && p.contexts >= 2) return "diverse";
  if (p.repetitions >= 3 && p.timeSpan >= 7) return "repeated";
  return "observed";
}

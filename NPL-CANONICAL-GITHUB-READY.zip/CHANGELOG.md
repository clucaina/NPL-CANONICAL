# NPL-CANONICAL changelog

## 0.1.0 · canonical recovery / brain gate hardening
- Preserved the canonical local `brain.glb` and manifest.
- Preserved `BrainViewer.tsx` and Living Brain Phase 1 code without rebuilding the atlas.
- Added a reproducible `brain_freeze_gate.py`.
- Added Capability Registry and Release Gate with strict state vocabulary.
- Recorded SHA-256 hashes for anatomy assets.
- Browser interactions are explicitly classified as QA-cache evidence until local Draco can decode the compressed canonical GLB.
- V41 remains archived and deliberately unconnected while `BRAIN_GATE=FAIL`.

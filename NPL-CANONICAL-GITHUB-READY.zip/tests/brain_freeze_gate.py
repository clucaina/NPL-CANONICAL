#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, struct, subprocess, sys, re, os

ROOT=Path(__file__).resolve().parents[1]
PUB=ROOT/'public/assets/brain'
DIST=ROOT/'dist'
DOCS=ROOT/'docs'
SRC=ROOT/'src/components/BrainViewer.tsx'
DEC=ROOT/'public/vendor/draco/gltf'


def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def glb_json(p):
    b=p.read_bytes()
    if len(b)<20: raise ValueError('GLB too small')
    magic,ver,total=struct.unpack_from('<4sII',b,0)
    if magic!=b'glTF' or ver!=2 or total!=len(b): raise ValueError('invalid GLB header')
    off=12
    while off<total:
        ln,tp=struct.unpack_from('<II',b,off); off+=8
        data=b[off:off+ln]; off+=ln
        if tp==0x4E4F534A: return json.loads(data.decode('utf-8'))
    raise ValueError('JSON chunk missing')

def check(name, ok, detail=''):
    status='PASS' if ok else 'FAIL'
    return {'name':name,'status':status,'detail':detail}

checks=[]
brain=PUB/'brain.glb'; manifest=PUB/'manifest.json'
checks.append(check('brain.glb local',brain.is_file(),str(brain)))
checks.append(check('manifest local',manifest.is_file(),str(manifest)))

j={}; draco_prims=0
if brain.is_file():
    try:
        j=glb_json(brain)
        draco_prims=sum(1 for m in j.get('meshes',[]) for p in m.get('primitives',[]) if 'KHR_draco_mesh_compression' in p.get('extensions',{}))
        checks.append(check('brain.glb requires Draco','KHR_draco_mesh_compression' in j.get('extensionsRequired',[]),f'{draco_prims} compressed primitives'))
        checks.append(check('atlas mesh registry',len(j.get('meshes',[]))==437,f"{len(j.get('meshes',[]))} meshes"))
    except Exception as e: checks.append(check('brain.glb parse',False,repr(e)))

manifest_count=None
if manifest.is_file():
    try:
        m=json.loads(manifest.read_text(encoding='utf-8'))
        arr=m if isinstance(m,list) else (m.get('structures') or m.get('nodes') or [])
        manifest_count=len(arr)
        checks.append(check('manifest registry',manifest_count==437,f'{manifest_count} structures'))
    except Exception as e: checks.append(check('manifest registry',False,repr(e)))

required_wasm=[DEC/'draco_wasm_wrapper.js',DEC/'draco_decoder.wasm']
js_decoder=DEC/'draco_decoder.js'
wasm_ok=all(p.is_file() and p.stat().st_size>10000 for p in required_wasm)
js_ok=js_decoder.is_file() and js_decoder.stat().st_size>10000
checks.append(check('Draco decoder vendored',wasm_ok or js_ok,
    'wasm pair present' if wasm_ok else ('JS decoder present' if js_ok else 'missing draco_wasm_wrapper.js + draco_decoder.wasm (or JS fallback)')))

src=SRC.read_text(encoding='utf-8') if SRC.exists() else ''
checks.append(check('canonical model path', '"/assets/brain/brain.glb"' in src or "'/assets/brain/brain.glb'" in src,'BrainViewer points to local source GLB'))
checks.append(check('canonical manifest path', '/assets/brain/manifest.json' in src,'BrainViewer points to local manifest'))
checks.append(check('canonical Draco path', '/vendor/draco/gltf/' in src,'BrainViewer points to local decoder path'))
remote_refs=re.findall(r'https?://[^\s\"\'`)>]+',src)
checks.append(check('no remote runtime dependency',len(remote_refs)==0,', '.join(remote_refs[:3]) if remote_refs else 'none'))

# A canonical release may not use the decompressed cache as the production model.
dist_html=(DIST/'index.html').read_text(encoding='utf-8',errors='ignore') if (DIST/'index.html').exists() else ''
uses_cache='brain.runtime.glb' in dist_html
checks.append(check('production dist uses source brain.glb',not uses_cache and 'brain.glb' in dist_html,
    'dist still references brain.runtime.glb QA cache' if uses_cache else 'source path detected'))

# Browser interaction evidence is accepted only as auxiliary when it ran against the QA cache.
browser_file=DOCS/'browser-gate.json'
browser={}
if browser_file.exists():
    try: browser=json.loads(browser_file.read_text())
    except: browser={}
interaction_keys=['brain_load','canvas','hover','select','focus','networks','progress_layer','hemisphere','cortex_opacity','reset','click_vs_drag','zoom','pan','rotate','search','mobile','touch_rotate']
aux_ok=all(browser.get(k)=='PASS' for k in interaction_keys)
checks.append(check('interaction regression suite (QA cache only)',aux_ok,'auxiliary only; cannot promote BRAIN_GATE without local Draco'))

hard_fail_names={'Draco decoder vendored','production dist uses source brain.glb'}
hard_failed=[c for c in checks if c['name'] in hard_fail_names and c['status']!='PASS']
canonical_browser_possible=(wasm_ok or js_ok) and not uses_cache
brain_gate='PASS' if not hard_failed and aux_ok and canonical_browser_possible else 'FAIL'

report={
  'gate':'BRAIN_GATE','status':brain_gate,
  'canonical_asset':str(brain.relative_to(ROOT)) if brain.exists() else None,
  'sha256':{'brain.glb':sha(brain) if brain.exists() else None,'manifest.json':sha(manifest) if manifest.exists() else None},
  'atlas':{'meshes':len(j.get('meshes',[])) if j else None,'manifestStructures':manifest_count,'dracoCompressedPrimitives':draco_prims},
  'checks':checks,
  'blocker':None if brain_gate=='PASS' else 'Local Draco decoder assets are absent; production dist is therefore not allowed to claim the compressed source brain.glb runtime.',
  'note':'The existing browser regression result exercises a decompressed QA cache and is evidence for interaction behavior only, not canonical-load PASS.'
}
DOCS.mkdir(exist_ok=True)
(DOCS/'BRAIN-GATE.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(report,indent=2,ensure_ascii=False))
sys.exit(0 if brain_gate=='PASS' else 2)

import asyncio, json, time, mimetypes, math
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path('/mnt/data/NPL-CANONICAL/dist')
OUT=Path('/mnt/data/NPL-CANONICAL/docs')

async def main():
    results={}
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=False, executable_path='/usr/bin/chromium', args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage'])
        ctx=await browser.new_context(viewport={'width':640,'height':480},device_scale_factor=1,has_touch=True,is_mobile=False)
        page=await ctx.new_page()
        await page.add_init_script('window.__NPL_TEST__=true')
        errors=[]
        page.on('pageerror',lambda e: errors.append('PAGE:'+str(e)))
        page.on('console',lambda m: errors.append('CONSOLE:'+m.text) if m.type=='error' else None)

        async def handler(route):
            u=route.request.url
            prefix='http://npl.local/'
            if u.startswith(prefix):
                rel=u[len(prefix):].split('?',1)[0]
                fp=ROOT/rel
                if fp.exists() and fp.is_file():
                    ctype=mimetypes.guess_type(fp.name)[0] or ('model/gltf-binary' if fp.suffix=='.glb' else 'application/octet-stream')
                    await route.fulfill(status=200,body=fp.read_bytes(),headers={'Content-Type':ctype,'Access-Control-Allow-Origin':'*'})
                    return
            await route.abort()
        await page.route('**/*',handler)
        html=(ROOT/'index.html').read_text(encoding='utf-8').replace('<head>','<head><base href="http://npl.local/">',1)
        t=time.time()
        await page.set_content(html,wait_until='domcontentloaded',timeout=30000)
        try:
            await page.wait_for_function('window.__NPL_BRAIN__ && window.__NPL_BRAIN__.ready === true',timeout=80000)
            results['brain_load']='PASS'
        except Exception as e:
            results['brain_load']='FAIL';results['load_error']=str(e)
        results['load_seconds']=round(time.time()-t,2)
        if results['brain_load']=='PASS':
            st=await page.evaluate('window.__NPL_BRAIN__.getState()')
            results['mesh_count']=await page.evaluate('window.__NPL_BRAIN__.meshCount')
            results['visible_initial']=st['visible']
            results['canvas']='PASS' if await page.locator('canvas').count() else 'FAIL'

            # Pick an actually projectable mesh and exercise hover + pointer selection.
            pt=await page.evaluate('''() => {
              const c=renderer.domElement.getBoundingClientRect();
              const candidates=meshes.filter(m=>m.visible);
              for (const m of candidates){
                const box=new THREE.Box3().setFromObject(m); const v=box.getCenter(new THREE.Vector3()).project(camera);
                if(v.z>-1 && v.z<1 && Math.abs(v.x)<.72 && Math.abs(v.y)<.72){
                  return {x:c.left+(v.x+1)*c.width/2,y:c.top+(1-v.y)*c.height/2,label:m.userData.meta.label};
                }
              }
              return {x:c.left+c.width/2,y:c.top+c.height/2,label:null};
            }''')
            await page.mouse.move(pt['x'],pt['y']); await page.wait_for_timeout(120)
            results['hover']='PASS' if await page.locator('#tooltip.show').count() else 'FAIL'
            await page.mouse.click(pt['x'],pt['y']); await page.wait_for_timeout(120)
            s1=await page.evaluate('window.__NPL_BRAIN__.getState()')
            results['select']='PASS' if s1.get('selected') else 'FAIL'
            if results['select']!='PASS':
                await page.evaluate('window.__NPL_BRAIN__.selectFirst()'); await page.wait_for_timeout(80)
                s1=await page.evaluate('window.__NPL_BRAIN__.getState()')
                results['select_fallback_api']='PASS' if s1.get('selected') else 'FAIL'

            before_focus=await page.evaluate('camera.position.toArray()')
            await page.evaluate('window.__NPL_BRAIN__.focus()');await page.wait_for_timeout(900)
            after_focus=await page.evaluate('camera.position.toArray()')
            results['focus']='PASS' if before_focus!=after_focus else 'FAIL'

            await page.evaluate("window.__NPL_BRAIN__.setMode('networks'); window.__NPL_BRAIN__.setNetwork('visual')");await page.wait_for_timeout(80)
            sn=await page.evaluate('window.__NPL_BRAIN__.getState()');results['networks']='PASS' if sn['mode']=='networks' and sn['activeNetwork']=='visual' else 'FAIL'
            await page.evaluate("window.__NPL_BRAIN__.setMode('progress')");await page.wait_for_timeout(80)
            sp=await page.evaluate('window.__NPL_BRAIN__.getState()');results['progress_layer']='PASS' if sp['mode']=='progress' else 'FAIL'
            await page.evaluate("window.__NPL_BRAIN__.setHemisphere('left')");await page.wait_for_timeout(80)
            sh=await page.evaluate('window.__NPL_BRAIN__.getState()');results['hemisphere']='PASS' if sh['hemisphere']=='left' and sh['visible']<results['visible_initial'] else 'FAIL'
            await page.evaluate('window.__NPL_BRAIN__.setOpacity(0.25)');await page.wait_for_timeout(50)
            so=await page.evaluate('window.__NPL_BRAIN__.getState()');results['cortex_opacity']='PASS' if abs(so['cortexOpacity']-.25)<.001 else 'FAIL'
            await page.evaluate('window.__NPL_BRAIN__.reset()');await page.wait_for_timeout(100)
            sr=await page.evaluate('window.__NPL_BRAIN__.getState()');results['reset']='PASS' if sr['hemisphere']=='both' and not sr.get('selected') else 'FAIL'

            canvas=page.locator('canvas');box=await canvas.bounding_box()
            if box:
                x=box['x']+box['width']*.55;y=box['y']+box['height']*.5
                cam0=await page.evaluate('camera.position.toArray()')
                await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x+70,y+18,steps=5);await page.mouse.up();await page.wait_for_timeout(100)
                sd=await page.evaluate('window.__NPL_BRAIN__.getState()'); cam1=await page.evaluate('camera.position.toArray()')
                results['click_vs_drag']='PASS' if not sd.get('selected') else 'FAIL'
                results['rotate']='PASS' if cam0!=cam1 else 'FAIL'

                d0=await page.evaluate('camera.position.distanceTo(controls.target)')
                await page.mouse.wheel(0,-420); await page.evaluate('controls.update(); renderer.render(scene,camera)'); await page.wait_for_timeout(100)
                d1=await page.evaluate('camera.position.distanceTo(controls.target)')
                results['zoom']='PASS' if abs(d1-d0)>1e-6 else 'FAIL'

                target0=await page.evaluate('controls.target.toArray()')
                await page.mouse.move(x,y);await page.mouse.down(button='right');await page.mouse.move(x+44,y+24,steps=4);await page.mouse.up(button='right');await page.evaluate('controls.update(); renderer.render(scene,camera)');await page.wait_for_timeout(100)
                target1=await page.evaluate('controls.target.toArray()')
                results['pan']='PASS' if target0!=target1 else 'FAIL'

                # Real touch path through CDP: one-finger drag/rotate on a touch-enabled mobile viewport.
                # Multi-touch pinch is intentionally not asserted in the pre-gate cache fixture because
                # SwiftShader/CDP in this container closes the target intermittently; canonical gate remains FAIL anyway.
                try:
                    cdp=await ctx.new_cdp_session(page)
                    await page.set_viewport_size({'width':390,'height':700}); await page.wait_for_timeout(100)
                    box=await canvas.bounding_box(); x=box['x']+box['width']*.52; y=box['y']+box['height']*.48
                    tc0=await page.evaluate('camera.position.toArray()')
                    await cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x,'y':y,'radiusX':4,'radiusY':4,'force':1}]})
                    await cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x+55,'y':y+28,'radiusX':4,'radiusY':4,'force':1}]})
                    await cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]})
                    await page.evaluate('controls.update(); renderer.render(scene,camera)'); await page.wait_for_timeout(120)
                    tc1=await page.evaluate('camera.position.toArray()')
                    results['touch_rotate']='PASS' if tc0!=tc1 else 'FAIL'
                    results['touch_event_path']='PASS'
                except Exception as e:
                    results['touch_rotate']='FAIL'; results['touch_event_path']='FAIL:'+str(e)

            await page.fill('#search','hippoc');await page.wait_for_timeout(80);results['search']='PASS' if await page.locator('#results button').count()>0 else 'FAIL'
            results['mobile']='PASS' if await page.locator('.topbar').count() and await page.locator('#search').count() and await page.evaluate('innerWidth')==390 else 'FAIL'
            try: await page.screenshot(path=str(OUT/'living-brain-phase1.png'),timeout=15000)
            except Exception as e: results['screenshot']='FAIL:'+str(e)
        results['errors']=errors[:8]
        (OUT/'browser-gate.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
        print(json.dumps(results,indent=2))
        try:
            await asyncio.wait_for(ctx.close(),timeout=4)
            await asyncio.wait_for(browser.close(),timeout=4)
        except Exception:
            pass

asyncio.run(main())

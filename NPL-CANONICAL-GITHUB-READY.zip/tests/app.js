
const $=id=>document.getElementById(id);
const NETWORKS=[{"id": "visual", "name": "Visual", "color": "#73b8ff", "desc": "Sistemas distribuidos implicados en análisis visual, integración espacial y representación de características.", "patterns": ["occipital", "cuneus", "calcarine", "lingual", "fusiform", "occipitotemporal", "optic radiation", "lateral geniculate"]}, {"id": "somatomotor", "name": "Somatomotora", "color": "#74d5a7", "desc": "Circuitos corticales y subcorticales vinculados con percepción corporal, preparación y control del movimiento.", "patterns": ["precentral", "postcentral", "paracentral", "corticospinal", "cerebell", "motor"]}, {"id": "dorsal_attention", "name": "Atención dorsal", "color": "#68d7e7", "desc": "Red distribuida de orientación voluntaria y selección de información relevante.", "patterns": ["superior parietal", "intraparietal", "superior frontal", "middle frontal", "frontal eye"]}, {"id": "salience", "name": "Atención ventral / salience", "color": "#f4b86b", "desc": "Sistemas que contribuyen a detectar relevancia, reorientar atención e integrar señales internas y externas.", "patterns": ["insula", "cingulate", "opercular", "supramarginal", "anterior cingulate"]}, {"id": "control", "name": "Frontoparietal / control", "color": "#bb9cff", "desc": "Sistemas distribuidos implicados en control flexible, mantenimiento de metas y ajuste de estrategias.", "patterns": ["middle frontal", "inferior frontal", "superior parietal", "inferior parietal", "angular gyrus", "cingulate"]}, {"id": "default", "name": "Default mode", "color": "#e7a8cb", "desc": "Conjunto distribuido relacionado con pensamiento interno, memoria autobiográfica y construcción de modelos de situación.", "patterns": ["precuneus", "posterior cingulate", "medial frontal", "angular gyrus", "parahippocamp", "hippocamp"]}, {"id": "language", "name": "Lenguaje", "color": "#f3d36f", "desc": "Conjunto frontotemporal distribuido para comprensión, producción y control lingüístico.", "patterns": ["inferior frontal", "opercular part", "triangular part", "superior temporal", "middle temporal", "angular gyrus", "supramarginal", "acoustic radiation"]}, {"id": "memory", "name": "Memoria", "color": "#82c7c2", "desc": "Sistemas distribuidos de codificación, consolidación, recuperación y contextualización de recuerdos.", "patterns": ["hippocamp", "parahippocamp", "entorhinal", "fornix", "mammillary", "posterior cingulate", "thalam"]}, {"id": "reward", "name": "Reward / value", "color": "#f28e83", "desc": "Circuitos distribuidos que contribuyen a valoración, aprendizaje por recompensa y selección orientada a metas.", "patterns": ["accumbens", "orbitofrontal", "orbital gyrus", "medial frontal", "caudate", "putamen", "amygdal"]}, {"id": "social", "name": "Mentalizing / social cognition", "color": "#89a9ef", "desc": "Sistemas distribuidos implicados en perspectiva social, modelos de otras personas y razonamiento sobre estados mentales.", "patterns": ["temporoparietal", "angular gyrus", "supramarginal", "precuneus", "posterior cingulate", "medial frontal", "temporal pole"]}];
const MOCK_PROGRESS={"visual": {"coverage": 0.58, "evidenceCount": 18, "evidenceDiversity": 4, "contexts": 3, "repetitions": 7, "timeSpan": 46, "transferEvidence": 2, "uncertainty": 0.22, "contradictions": 0, "lastEvidence": "hace 2 días", "trend": "estable", "confidence": 0.72}, "somatomotor": {"coverage": 0.22, "evidenceCount": 6, "evidenceDiversity": 2, "contexts": 2, "repetitions": 3, "timeSpan": 16, "transferEvidence": 0, "uncertainty": 0.48, "contradictions": 0, "lastEvidence": "hace 6 días", "trend": "explorando", "confidence": 0.42}, "dorsal_attention": {"coverage": 0.48, "evidenceCount": 14, "evidenceDiversity": 3, "contexts": 3, "repetitions": 6, "timeSpan": 34, "transferEvidence": 1, "uncertainty": 0.31, "contradictions": 0, "lastEvidence": "hoy", "trend": "cambio reciente", "confidence": 0.63}, "salience": {"coverage": 0.31, "evidenceCount": 8, "evidenceDiversity": 3, "contexts": 2, "repetitions": 4, "timeSpan": 21, "transferEvidence": 0, "uncertainty": 0.62, "contradictions": 2, "lastEvidence": "hace 4 días", "trend": "contradictorio", "confidence": 0.34}, "control": {"coverage": 0.62, "evidenceCount": 21, "evidenceDiversity": 5, "contexts": 4, "repetitions": 8, "timeSpan": 55, "transferEvidence": 2, "uncertainty": 0.26, "contradictions": 1, "lastEvidence": "ayer", "trend": "estable", "confidence": 0.74}, "default": {"coverage": 0.12, "evidenceCount": 3, "evidenceDiversity": 1, "contexts": 1, "repetitions": 2, "timeSpan": 5, "transferEvidence": 0, "uncertainty": 0.73, "contradictions": 0, "lastEvidence": "hace 5 días", "trend": "inicial", "confidence": 0.22}, "language": {"coverage": 0.39, "evidenceCount": 10, "evidenceDiversity": 4, "contexts": 3, "repetitions": 5, "timeSpan": 29, "transferEvidence": 1, "uncertainty": 0.36, "contradictions": 0, "lastEvidence": "hace 3 días", "trend": "creciendo", "confidence": 0.59}, "memory": {"coverage": 0.45, "evidenceCount": 12, "evidenceDiversity": 3, "contexts": 3, "repetitions": 5, "timeSpan": 40, "transferEvidence": 1, "uncertainty": 0.38, "contradictions": 1, "lastEvidence": "hoy", "trend": "variable", "confidence": 0.55}, "reward": {"coverage": 0, "evidenceCount": 0, "evidenceDiversity": 0, "contexts": 0, "repetitions": 0, "timeSpan": 0, "transferEvidence": 0, "uncertainty": 1, "contradictions": 0, "lastEvidence": "sin evidencia", "trend": "desconocido", "confidence": 0}, "social": {"coverage": 0.28, "evidenceCount": 7, "evidenceDiversity": 3, "contexts": 3, "repetitions": 3, "timeSpan": 26, "transferEvidence": 1, "uncertainty": 0.44, "contradictions": 0, "lastEvidence": "hace 1 semana", "trend": "explorando", "confidence": 0.49}};
const RUNTIME_MODEL='./assets/brain/brain.runtime.glb';
const MANIFEST='./assets/brain/manifest.json';

let scene,camera,renderer,controls,brainRoot,raycaster;
let meshes=[], selected=null, hovered=null, selectionGroup=[];
let manifestByNorm=new Map(), manifestById=new Map();
let mode='anatomy', activeNetwork='control', hemisphere='both', cortexOpacity=.86;
let layers={cortex:true,deep:true,tracts:true,brainstem:true,cerebellum:true,vessels:false,nerves:false};
let pointer={x:0,y:0,clientX:0,clientY:0,dirty:false,inside:false,downX:0,downY:0,downT:0,moved:false,multi:false};
let hoverTimer=null, dragActive=false, home=null, flyToken=0, networkLines=null;
const BASE=new Map();
const labelCache=new Map();

function norm(s){return (s||'').toLowerCase().trim().replace(/[_-]+/g,' ').replace(/\.\d{3}$/,'').replace(/\.(l|r)$/,'').replace(/\s+/g,' ')}
function safeLabel(m){return (m?.userData?.meta?.label)||m?.name||'Estructura'}
function categoryGroup(cat){
 if(cat==='cortex')return 'cortex';
 if(['deep_grey','diencephalon','ventricles','white_matter'].includes(cat))return 'deep';
 if(cat==='tracts')return 'tracts';
 if(cat==='brainstem')return 'brainstem';
 if(cat==='cerebellum')return 'cerebellum';
 if(['arteries','veins_sinuses','meninges_dura'].includes(cat))return 'vessels';
 if(cat==='cranial_nerves')return 'nerves'; return 'deep';
}
function inferLobe(meta){
 const r=(meta.region||'').toLowerCase(), l=(meta.label||'').toLowerCase();
 const s=r+' '+l;
 if(s.includes('frontal'))return 'Lóbulo frontal';
 if(s.includes('parietal')||s.includes('angular')||s.includes('supramarginal'))return 'Lóbulo parietal';
 if(s.includes('temporal')||s.includes('fusiform')||s.includes('entorhinal')||s.includes('hippocamp'))return 'Lóbulo temporal';
 if(s.includes('occipital')||s.includes('cuneus')||s.includes('calcarine')||s.includes('lingual'))return 'Lóbulo occipital';
 if(s.includes('insula'))return 'Ínsula';
 if(s.includes('cingulat'))return 'Cíngulo / medial';
 if(meta.category==='cerebellum')return 'Cerebelo';
 if(meta.category==='brainstem')return 'Tronco encefálico';
 if(['deep_grey','diencephalon','ventricles','white_matter'].includes(meta.category))return 'Estructuras profundas';
 if(meta.category==='tracts')return 'Tractos';
 return meta.region||'Otras estructuras';
}
function hierarchy(meta){
 const hemi=meta.side==='left'?'Hemisferio izquierdo':meta.side==='right'?'Hemisferio derecho':'Mediano / bilateral';
 return ['Cerebro',hemi,inferLobe(meta),meta.region||meta.category,meta.label].filter((x,i,a)=>x&&a.indexOf(x)===i);
}
function baseColor(cat){
 const c={cortex:0xd4b8ae,deep_grey:0xb596a8,diencephalon:0xc7a879,tracts:0xe6ddc3,white_matter:0xe5ddd3,ventricles:0x86b7c5,brainstem:0xc78f79,cerebellum:0xbca69c,arteries:0x9e4d4c,veins_sinuses:0x576e91,cranial_nerves:0xd4bd83,meninges_dura:0xb99d8c};
 return c[cat]||0xb3aaa5;
}
function progressState(p){
 if(!p||p.evidenceCount===0)return {key:'unknown',label:'Todavía desconocido'};
 if(p.contradictions>=2)return {key:'contradictory',label:'Evidencia contradictoria'};
 if(p.uncertainty>=.6)return {key:'uncertain',label:'Todavía incierto'};
 if(p.timeSpan>=30&&p.repetitions>=6&&p.evidenceDiversity>=4&&p.contexts>=3&&p.transferEvidence>=2&&p.uncertainty<.35)return {key:'stable',label:'Patrón estable'};
 if(p.transferEvidence>=1&&p.contexts>=3)return {key:'transferred',label:'Transferencia observada'};
 if(p.evidenceDiversity>=3&&p.contexts>=2)return {key:'diverse',label:'Evidencia diversa'};
 if(p.repetitions>=3&&p.timeSpan>=7)return {key:'repeated',label:'Repetido en el tiempo'};
 return {key:'observed',label:'Primeras observaciones'};
}
function networkMatches(mesh,net){
 const m=mesh.userData.meta||{}; const text=(m.label+' '+m.region+' '+m.category).toLowerCase();
 return net.patterns.some(p=>text.includes(p.toLowerCase()));
}
function isVisibleByFilters(m){
 const meta=m.userData.meta||{}; if(hemisphere!=='both'&&meta.side!==hemisphere&&meta.side!=='median')return false;
 const g=categoryGroup(meta.category); return layers[g]!==false;
}
function applyVisualState(){
 clearNetworkLines();
 const net=NETWORKS.find(n=>n.id===activeNetwork);
 const p=MOCK_PROGRESS[activeNetwork]; const ps=progressState(p);
 meshes.forEach(m=>{
   const meta=m.userData.meta||{}; const mat=m.material;
   m.visible=isVisibleByFilters(m) && (!m.userData.isolatedHidden);
   mat.color.setHex(baseColor(meta.category)); mat.emissive.setHex(0x000000); mat.emissiveIntensity=0;
   mat.transparent=true; mat.opacity=(meta.category==='cortex'?cortexOpacity:BASE.get(m)?.opacity||.96);
   mat.depthWrite=mat.opacity>.58; mat.wireframe=false;
   if(mode==='networks'&&net){
     const match=networkMatches(m,net); mat.opacity=match?Math.max(mat.opacity,.9):Math.min(mat.opacity,.11);
     if(match){mat.color.set(net.color);mat.emissive.set(net.color);mat.emissiveIntensity=.12;}
   }
   if(mode==='progress'&&net){
     const match=networkMatches(m,net); mat.opacity=match?Math.max(mat.opacity,.85):Math.min(mat.opacity,.07);
     if(match){
       let strength={unknown:0,observed:.08,repeated:.12,diverse:.18,transferred:.24,stable:.3,uncertain:.08,contradictory:.1}[ps.key]||0;
       mat.color.set(net.color);mat.emissive.set(net.color);mat.emissiveIntensity=strength;
       if(ps.key==='unknown'){mat.color.setHex(0x858585);mat.opacity=.18;}
     }
   }
   if(m===selected){mat.color.setHex(0xf4eee9);mat.emissive.setHex(0xd59a7a);mat.emissiveIntensity=.36;mat.opacity=1;}
   else if(m===hovered){mat.emissive.setHex(0xffffff);mat.emissiveIntensity=.12;mat.opacity=Math.max(mat.opacity,.9);}
 });
 if((mode==='networks'||mode==='progress')&&net)buildNetworkLines(net,p,ps);
 updateContext(); renderer.render(scene,camera);
}
function clearNetworkLines(){if(networkLines){scene.remove(networkLines);networkLines.geometry?.dispose();networkLines.material?.dispose();networkLines=null;}}
function buildNetworkLines(net,p,ps){
 let nodes=meshes.filter(m=>m.visible&&networkMatches(m,net));
 if(nodes.length<2)return; nodes=nodes.slice(0,26);
 const centers=nodes.map(m=>new THREE.Box3().setFromObject(m).getCenter(new THREE.Vector3()));
 const verts=[]; for(let i=1;i<centers.length;i++){let j=Math.floor((i-1)/2); verts.push(...centers[j].toArray(),...centers[i].toArray())}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));
 let op=mode==='progress'?({unknown:.03,observed:.1,repeated:.16,diverse:.24,transferred:.32,stable:.4,uncertain:.09,contradictory:.12}[ps.key]||.1):.22;
 const mat=new THREE.LineBasicMaterial({color:new THREE.Color(net.color),transparent:true,opacity:op,depthTest:true});
 networkLines=new THREE.LineSegments(g,mat);scene.add(networkLines);
}
function selectMesh(m,{focus=false}={}){selected=m||null; if(selected){selectionGroup=[selected]; $('context').classList.add('open'); if(focus)flyTo(selected);} applyVisualState();}
function fitMeshes(group,duration=650){
 if(!group||!group.length)return; const box=new THREE.Box3();group.forEach(m=>box.expandByObject(m)); if(box.isEmpty())return;
 const sphere=box.getBoundingSphere(new THREE.Sphere()); const fromP=camera.position.clone(),fromT=controls.target.clone();
 const dir=fromP.clone().sub(fromT).normalize(); const fov=camera.fov*Math.PI/180; const dist=Math.max(sphere.radius/Math.tan(fov/2)*1.55,.05); const toT=sphere.center.clone(),toP=toT.clone().add(dir.multiplyScalar(dist));
 const token=++flyToken,t0=performance.now(); function step(now){if(token!==flyToken)return;let t=Math.min(1,(now-t0)/duration),e=1-Math.pow(1-t,3);camera.position.lerpVectors(fromP,toP,e);controls.target.lerpVectors(fromT,toT,e);controls.update();renderer.render(scene,camera);if(t<1)requestAnimationFrame(step)}requestAnimationFrame(step);
}
function flyTo(m){if(m)fitMeshes([m],600)}
function resetView(){
 ++flyToken; selected=null;hovered=null;selectionGroup=[];hemisphere='both';cortexOpacity=.86; layers={cortex:true,deep:true,tracts:true,brainstem:true,cerebellum:true,vessels:false,nerves:false};
 document.querySelectorAll('[data-hemi]').forEach(b=>b.classList.toggle('active',b.dataset.hemi==='both')); $('opacity').value=cortexOpacity;
 if(home){camera.position.copy(home.pos);controls.target.copy(home.target);controls.update();} $('context').classList.remove('open'); applyVisualState();
}
function isolateSelection(){if(!selected)return;meshes.forEach(m=>m.userData.isolatedHidden=m!==selected);applyVisualState();fitMeshes([selected],500)}
function showAll(){meshes.forEach(m=>m.userData.isolatedHidden=false);applyVisualState()}
function setMode(m){mode=m;document.querySelectorAll('[data-mode]').forEach(b=>b.classList.toggle('active',b.dataset.mode===m)); $('networkDock').classList.toggle('show',m==='networks'||m==='progress');applyVisualState()}
function setNetwork(id){activeNetwork=id;document.querySelectorAll('[data-net]').forEach(b=>b.classList.toggle('active',b.dataset.net===id));applyVisualState();let n=NETWORKS.find(x=>x.id===id);let group=meshes.filter(m=>m.visible&&networkMatches(m,n));if(group.length)fitMeshes(group,600)}
function updateContext(){
 const panel=$('context');
 if(selected){const m=selected.userData.meta||{}; $('contextTitle').textContent=m.label||selected.name; $('contextKind').textContent=(m.category||'estructura').replaceAll('_',' '); let h=hierarchy(m);$('crumbs').innerHTML=h.map((x,i)=>`<button data-level="${i}">${x}</button>${i<h.length-1?'<span>›</span>':''}`).join('');
   let nets=NETWORKS.filter(n=>networkMatches(selected,n));$('contextBody').innerHTML=`<div class="fact"><span>Hemisferio</span><b>${m.side==='left'?'Izquierdo':m.side==='right'?'Derecho':'Mediano / bilateral'}</b></div><div class="fact"><span>Procedencia</span><b>${m.source||'Atlas anatómico'}</b></div><div class="netlist"><small>REDES RELACIONADAS · MAPEO EDUCATIVO</small>${nets.length?nets.map(n=>`<button data-go-net="${n.id}" style="--net:${n.color}">${n.name}</button>`).join(''):'<em>Sin mapeo inicial todavía</em>'}</div>`;
   panel.querySelectorAll('[data-go-net]').forEach(b=>b.onclick=()=>{setMode('networks');setNetwork(b.dataset.goNet)});
   panel.querySelectorAll('[data-level]').forEach(b=>b.onclick=()=>selectHierarchyLevel(+b.dataset.level,h,m));
 } else if(mode==='networks'||mode==='progress'){
   const n=NETWORKS.find(x=>x.id===activeNetwork),p=MOCK_PROGRESS[activeNetwork],s=progressState(p);panel.classList.add('open');$('contextTitle').textContent=n.name;$('contextKind').textContent=mode==='progress'?'PROGRESO NPL · MOCK':'RED FUNCIONAL DISTRIBUIDA';$('crumbs').innerHTML='<button>Cerebro</button><span>›</span><button>Redes</button><span>›</span><button>'+n.name+'</button>';
   $('contextBody').innerHTML=`<p class="desc">${n.desc}</p><div class="state ${s.key}">${s.label}</div>${mode==='progress'?`<div class="mock">DATOS MOCK · solo validación visual</div><div class="evidence"><div><b>${p.evidenceCount}</b><span>observaciones</span></div><div><b>${p.evidenceDiversity}</b><span>tipos de evidencia</span></div><div><b>${p.contexts}</b><span>contextos</span></div><div><b>${p.transferEvidence}</b><span>transferencias</span></div></div><p class="desc">${p.repetitions>=3?'Hay repetición temporal. ':'Aún falta repetición temporal. '}${p.evidenceDiversity<3?'Necesitamos más variedad de experiencias. ':''}${p.uncertainty>.55?'La evidencia actual mantiene alta incertidumbre. ':''}</p>`:''}<button class="primary">Seguir explorando esta red</button>`;
 } else if(!selected){panel.classList.remove('open')}
}
function selectHierarchyLevel(level,h,meta){
 if(level>=h.length-1){selectMesh(selected,{focus:true});return}
 let group=[]; if(level===0)group=meshes.filter(m=>m.visible); else if(level===1)group=meshes.filter(m=>m.visible&&(m.userData.meta.side===meta.side||m.userData.meta.side==='median')); else if(level===2){let l=inferLobe(meta);group=meshes.filter(m=>m.visible&&inferLobe(m.userData.meta)===l)} else if(level===3)group=meshes.filter(m=>m.visible&&m.userData.meta.region===meta.region);
 if(group.length){selectionGroup=group;fitMeshes(group,600)}
}
function setupNetworkDock(){let d=$('networkDock');d.innerHTML=NETWORKS.map(n=>`<button data-net="${n.id}" style="--net:${n.color}"><i></i>${n.name}</button>`).join('');d.querySelectorAll('[data-net]').forEach(b=>b.onclick=()=>setNetwork(b.dataset.net));d.querySelector(`[data-net="${activeNetwork}"]`)?.classList.add('active')}
function setupLayers(){document.querySelectorAll('[data-layer]').forEach(b=>b.onclick=()=>{let k=b.dataset.layer;layers[k]=!layers[k];b.classList.toggle('active',layers[k]);applyVisualState()});document.querySelectorAll('[data-hemi]').forEach(b=>b.onclick=()=>{hemisphere=b.dataset.hemi;document.querySelectorAll('[data-hemi]').forEach(x=>x.classList.toggle('active',x===b));applyVisualState()});}
function setupSearch(){let input=$('search'),results=$('results');input.oninput=()=>{let q=norm(input.value);if(q.length<2){results.classList.remove('show');return}let hits=meshes.filter(m=>norm(safeLabel(m)).includes(q)||norm(m.userData.meta.region).includes(q)).slice(0,12);results.innerHTML=hits.map((m,i)=>`<button data-i="${i}"><span>${safeLabel(m)}</span><small>${inferLobe(m.userData.meta)} · ${m.userData.meta.side}</small></button>`).join('');results.classList.toggle('show',!!hits.length);results.querySelectorAll('[data-i]').forEach(b=>b.onclick=()=>{selectMesh(hits[+b.dataset.i],{focus:true});input.value='';results.classList.remove('show')})};}
function updatePointer(ev){const r=renderer.domElement.getBoundingClientRect();pointer.x=((ev.clientX-r.left)/r.width)*2-1;pointer.y=-((ev.clientY-r.top)/r.height)*2+1;pointer.clientX=ev.clientX;pointer.clientY=ev.clientY;pointer.dirty=true;pointer.inside=true;}
function pickAtPointer(allowFallback=false){raycaster.setFromCamera(new THREE.Vector2(pointer.x,pointer.y),camera);let candidates=meshes.filter(m=>m.visible);let hits=raycaster.intersectObjects(candidates,false);if(hits.length)return hits[0].object;if(!allowFallback)return null;
 // touch/small-region aid: choose a near projected center only when direct triangle picking misses
 let best=null,bestD=innerWidth<700?20:12;const v=new THREE.Vector3();for(const m of candidates){new THREE.Box3().setFromObject(m).getCenter(v);v.project(camera);let sx=(v.x+1)*.5*innerWidth,sy=(-v.y+1)*.5*innerHeight,d=Math.hypot(sx-pointer.clientX,sy-pointer.clientY);if(d<bestD){bestD=d;best=m}}return best;}
function scheduleHover(){if(hoverTimer||dragActive||!pointer.inside)return;hoverTimer=setTimeout(()=>{hoverTimer=null;if(!pointer.dirty||dragActive)return;pointer.dirty=false;let m=pickAtPointer(false);if(m!==hovered){hovered=m;applyVisualState();let tip=$('tooltip');if(m){tip.textContent=safeLabel(m);tip.style.transform=`translate(${pointer.clientX+14}px,${pointer.clientY+14}px)`;tip.classList.add('show')}else tip.classList.remove('show')}},46)}
function setupPointer(){let el=renderer.domElement;el.style.touchAction='none';el.addEventListener('pointerdown',ev=>{updatePointer(ev);pointer.downX=ev.clientX;pointer.downY=ev.clientY;pointer.downT=performance.now();pointer.moved=false;pointer.multi=ev.isPrimary===false;dragActive=false;el.classList.add('grabbing')},{passive:true});el.addEventListener('pointermove',ev=>{updatePointer(ev);if(Math.hypot(ev.clientX-pointer.downX,ev.clientY-pointer.downY)>(innerWidth<700?10:6)){pointer.moved=true;dragActive=true;$('tooltip').classList.remove('show')}else scheduleHover()},{passive:true});el.addEventListener('pointerup',ev=>{updatePointer(ev);el.classList.remove('grabbing');const click=!pointer.moved&&!pointer.multi&&performance.now()-pointer.downT<650;dragActive=false;if(click){let m=pickAtPointer(true);if(m)selectMesh(m)}setTimeout(scheduleHover,50)},{passive:true});el.addEventListener('pointerleave',()=>{pointer.inside=false;hovered=null;$('tooltip').classList.remove('show');applyVisualState()},{passive:true});}
async function init(){
 $('loadText').textContent='Preparando atlas anatómico…';scene=new THREE.Scene();camera=new THREE.PerspectiveCamera(42,innerWidth/innerHeight,.001,100);renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.75));renderer.setSize(innerWidth,innerHeight);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;$('stage').appendChild(renderer.domElement);
 scene.add(new THREE.HemisphereLight(0xf8f3ee,0x202632,1.45));let key=new THREE.DirectionalLight(0xfff4eb,2.5);key.position.set(2.5,3.5,4);scene.add(key);let fill=new THREE.DirectionalLight(0xb9d2ea,1.0);fill.position.set(-3,1,-2);scene.add(fill);let rim=new THREE.DirectionalLight(0xffc8b5,.75);rim.position.set(2,-2,-3);scene.add(rim);
 controls=new THREE.TrackballControls(camera,renderer.domElement);controls.rotateSpeed=2.3;controls.zoomSpeed=1.3;controls.panSpeed=.72;controls.dynamicDampingFactor=.14;controls.staticMoving=false;controls.addEventListener('start',()=>{dragActive=true});controls.addEventListener('end',()=>{setTimeout(()=>{dragActive=false},35)});controls.addEventListener('change',()=>renderer.render(scene,camera));raycaster=new THREE.Raycaster();
 let mf=await fetch(MANIFEST).then(r=>r.json());for(const x of mf.nodes){manifestById.set(x.id,x);manifestByNorm.set(norm(x.name),x);if(!manifestByNorm.has(norm(x.label)))manifestByNorm.set(norm(x.label),x)}
 $('loadText').textContent='Cargando cerebro 3D real…';let loader=new THREE.GLTFLoader();loader.load(RUNTIME_MODEL,g=>{brainRoot=g.scene;scene.add(brainRoot);brainRoot.traverse(o=>{if(!o.isMesh)return;let meta=manifestByNorm.get(norm(o.name))||manifestByNorm.get(norm(o.parent?.name))||{id:null,label:o.name,category:'other',side:'median',region:'',source:'atlas'};o.userData.meta=meta;o.material=new THREE.MeshStandardMaterial({color:baseColor(meta.category),roughness:.72,metalness:.015,transparent:true,opacity:meta.category==='cortex'?cortexOpacity:.96,side:THREE.DoubleSide});BASE.set(o,{opacity:o.material.opacity});meshes.push(o)});
   // fit only CNS/core-ish brain categories, not peripheral nerves/vessels by default
   let fit=meshes.filter(m=>!['arteries','veins_sinuses','cranial_nerves','meninges_dura'].includes(m.userData.meta.category));if(!fit.length)fit=meshes;let box=new THREE.Box3();fit.forEach(m=>box.expandByObject(m));let sphere=box.getBoundingSphere(new THREE.Sphere());let dist=sphere.radius/Math.tan(camera.fov*Math.PI/360)*1.35;camera.position.copy(sphere.center.clone().add(new THREE.Vector3(dist*.1,dist*.08,dist)));controls.target.copy(sphere.center);camera.near=Math.max(.0001,dist/100);camera.far=dist*100;camera.updateProjectionMatrix();controls.minDistance=dist*.18;controls.maxDistance=dist*5;controls.update();home={pos:camera.position.clone(),target:controls.target.clone()};
   setupPointer();applyVisualState();$('loader').classList.add('done');$('meshCount').textContent=meshes.length+' mallas';window.__NPL_BRAIN__={ready:true,meshCount:meshes.length,selectFirst:()=>selectMesh(meshes.find(m=>m.visible)),focus:()=>flyTo(selected),reset:resetView,setMode,setNetwork,setHemisphere:h=>{hemisphere=h;applyVisualState()},setOpacity:v=>{cortexOpacity=v;applyVisualState()},getState:()=>({mode,activeNetwork,selected:selected?selected.userData.meta.label:null,hemisphere,cortexOpacity,visible:meshes.filter(m=>m.visible).length})}; animate();
 },xhr=>{if(xhr.total)$('loadText').textContent='Cargando cerebro 3D real… '+Math.round(xhr.loaded/xhr.total*100)+'%'},err=>{$('loader').classList.remove('done');$('loadText').textContent='ERROR: cerebro anatómico no cargado · '+(err.message||err)});
}
function animate(){if(window.__NPL_TEST__){controls.update();renderer.render(scene,camera);return;}requestAnimationFrame(animate);controls.update();renderer.render(scene,camera)}
window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);controls.handleResize?.();renderer.render(scene,camera)});
window.addEventListener('DOMContentLoaded',()=>{setupNetworkDock();setupLayers();setupSearch();document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>setMode(b.dataset.mode));$('opacity').oninput=e=>{cortexOpacity=+e.target.value;applyVisualState()};$('focus').onclick=()=>flyTo(selected);$('isolate').onclick=isolateSelection;$('showAll').onclick=showAll;$('reset').onclick=resetView;$('closeContext').onclick=()=>$('context').classList.remove('open');init()});

# NPL V39 — Contrato de continuidad y producto

## Invariante central
NPL es una superapp personal y social, activa y longitudinal. La experiencia visible debe ser simple, entretenida y accionable; la complejidad epistemológica queda debajo y debe ser accesible cuando el usuario pregunta «¿por qué?». Cada interacción debe cumplir al menos una de estas funciones: producir evidencia útil, ayudar a una meta real, profundizar una relación consensuada, enseñar algo útil o crear un objeto compartible seguro.

## Home — perfilación viva
- El primer valor tras entrar es el propio perfil, no una landing ni un dashboard técnico.
- Distingue estado actual, patrón longitudinal, contexto, cambio, cobertura e incertidumbre.
- Contiene acciones inmediatas: jugar, contar, probar, conectar, decidir, aprender, descansar.
- Tiene gráficos interactivos, historias/resúmenes, progreso, Gemelo, Cerebro, metas, relaciones y contexto.
- Nunca convierte cobertura en «puntuación de persona» ni castiga rachas.

## Cerebro — Brain Gate
La release no puede declarar el cerebro «terminado» si no dispone de una malla anatómica humana real con procedencia/licencia, selección jerárquica y navegación profunda.

Capas obligatorias:
1. anatomía real educativa;
2. sistemas/redes funcionales como capa conceptual;
3. progreso de aprendizaje/exploración;
4. NPL Cognitive Core, claramente separado del cerebro biológico.

Interacción mínima:
- rotación, zoom/pinch, pan;
- búsqueda por estructura/sistema;
- selección y focus-to-region;
- opacidad cortical;
- hemisferio izquierdo/derecho/ambos;
- capas corteza/profundo/tractos/ventrículos;
- isolate;
- explode;
- zoom semántico macro → sistema → estructura → núcleos/detalle;
- ficha con anatomía, función, En NPL, juego, fuentes/límites;
- ruta «de señal a aprendizaje»;
- experiencia/misión asociada.

Regla científica: NPL no infiere activación cerebral individual desde conducta, localización, perfil o juegos. «Mi progreso» significa exploración/aprendizaje o evidencia conductual relacionada con conceptos, nunca neuroimagen inventada.

## Gemelo
Modelo revisable de la persona. Mantiene hipótesis competidoras, falsadores, contradicciones, límites contextuales, predicciones previas al outcome, correcciones y trazabilidad. Puede responder «no lo sé» y permitir «esto no me representa».

## Mi Vida
WORLDLINE + eventos + decisiones + metas + relaciones + familia + estrategias + experimentos + outcomes + contexto. Conserva el antes/después, cambios de nivel y explicaciones alternativas.

## Juega / Explora
Mundos, temporadas, microexperiencias, retos, historias, humor, decisiones, puzzles, audio/vídeo futuro, cooperación, misiones de vida real y formatos creativos. La dificultad y modalidad son multidimensionales; la app evita fatiga y repetición cosmética.

## Conecta
Red social propia basada en intención y experiencias. Anonimato primero cuando corresponda, reciprocidad antes de revelar más información, matching sin salud/diagnóstico/sexualidad/familia/política/religión/localización exacta. Pulsos finitos, retos, salas, dúos, experimentos colectivos descriptivos y constelación relacional.

## Contexto / Conflictómetro
Conector futuro de señales agregadas territoriales, sociales, económicas, políticas, culturales, climáticas e informacionales. El motor puede contrastar si una trayectoria coincide con cambios de entorno y diseñar preguntas/experimentos; nunca convierte el territorio en identidad, ideología, religión, personalidad, diagnóstico, criminalidad o destino individual.

## NeuroMind / BelBrain → NPL Cognitive Core
Se conserva la I+D sobre atención, memoria, emoción funcional, integración, metacognición, imaginación, aprendizaje, razonamiento y self-model. El Cognitive Core es un modelo artificial experimental. No se confunde con el Cerebro anatómico ni con Mi Gemelo.

## Perfil profundo
28 dominios visibles y conectados: atención, memoria, ejecutiva, lenguaje, aprendizaje, decisión, metacognición, creatividad, emoción, estrés, motivación, hábitos, sueño, interocepción, sensorimotor, social, comunicación, relaciones, apego, familia, autoconocimiento, metas, trabajo/estudio, dinero, vida digital, juego/humor, intimidad adulta y contexto vital.

## Catálogo
La build debe conservar el inventario V37 de 101.392 unidades estructurales gobernadas y diferenciar número de unidades estructurales de contenido científico materializado. El selector adaptativo no muestra el catálogo bruto: lo transforma en variedad personalizada y trazable.

## Gamificación
XP, niveles, rutas, mundos, logros, colecciones, misiones, temporadas y retos, sin castigo por racha ni presión dañina. La seguridad puede suprimir gamificación. Ranking, si existe, debe priorizar cooperación/aprendizaje y no valor personal, salud o estatus.

## Accesibilidad y adaptación
Texto, contraste, movimiento, estimulación, temporizador, captions, idioma/locale, lectura y confort social son preferencias de entrega. No se usan para inferir identidad o perfil psicológico.

## Privacidad / menores / investigación
Separación privada/compartible/pública; propósito y consentimiento; exportación/borrado; RLS; separación estructural de menores/adultos; investigación formal separada de personalización y analítica; no scoring de credibilidad, culpa, criminalidad o diagnóstico autónomo.
